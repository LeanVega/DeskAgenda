# DeskAgenda Launcher PowerShell 
$jarPath = Join-Path $PSScriptRoot "DeskAgenda_Completo.jar" 
if (Test-Path $jarPath) { 
    Start-Process "javaw" -ArgumentList "-jar", "`"$jarPath`"" -WindowStyle Hidden 
} else { 
    [System.Windows.Forms.MessageBox]::Show("JAR no encontrado: $jarPath", "Error") 
} 
