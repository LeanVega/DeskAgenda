ARCHIVOS INCLUIDOS: 
 
Iniciar_DeskAgenda.bat - MENU PRINCIPAL 
DeskAgenda.vbs - Ejecutar SIN CONSOLA (RECOMENDADO) 
DeskAgenda_silencioso.bat - Ejecutar silencioso 
DeskAgenda.ps1 - Ejecutar con PowerShell 
DeskAgenda_Completo.jar - Aplicación principal 


